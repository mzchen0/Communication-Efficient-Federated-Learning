%Overlapped windowing
function [y_test_raw_target,y_train_split,y_test_split,y_train_split_target,...
    y_test_split_target] = EMGdataprocess3_new_FL(y,n)

%rng('default');

Window = 500;
Incre = 50;
Datalength = size(y,1);

label = 1:size(y,2); 
Train_label = label(1:16);
Test_label = setdiff(label,Train_label);      
        
y_train = y(:,Train_label);
y_test = y(:,Test_label);

y_train_raw = {};
for i = 0:size(Train_label,2)/8-1
        y_train_raw{i+1} = y_train(:,8*i+1:8*i+8);
end

y_train_raw_target = zeros(15,size(Train_label,2)/8);
y_train_raw_target(n,:) = ones(1,size(Train_label,2)/8);

y_test_raw = {};
for i = 0:size(Test_label,2)/8-1
    y_test_raw{i+1} = y_test(:,8*i+1:8*i+8);
end
y_test_raw_target = zeros(15,size(Test_label,2)/8);
y_test_raw_target(n,:) = ones(1,size(Test_label,2)/8);

split_samples = (Datalength - Window)/Incre + 1;

y_train_split = {};
for i = 0:numel(y_train_raw)-1
    for j = 0:split_samples-1
        y_train_split{i*(split_samples)+j+1} = y_train_raw{i+1}(Incre*j+1:Incre*j+Window,:);
    end
end

y_train_split_target = zeros(15,numel(y_train_split));
y_train_split_target(n,:) = ones(1,numel(y_train_split));

y_test_split = {};
for i = 0:numel(y_test_raw)-1
    for j = 0:split_samples-1
        y_test_split{i*(split_samples)+j+1} = y_test_raw{i+1}(Incre*j+1:Incre*j+Window,:);
    end
end

y_test_split_target = zeros(15,numel(y_test_split));
y_test_split_target(n,:) = ones(1,numel(y_test_split));

end