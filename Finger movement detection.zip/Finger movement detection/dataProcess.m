for j = 1:8
    
    foldername = strcat('S',num2str(j),'-Delsys-15Class');
    eval(['cd', ' ',foldername])

    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%% ??????????? a???15????i??????
    allMov = {'HC_', 'I_I', 'I_M', 'IMR', 'L_L', 'M_M', 'M_R', 'MRL', 'R_L', 'R_R', 'T_I', 'T_L', 'T_M', 'T_R', 'T_T'};
    for a = 1:15
        Varname = strcat('S',num2str(j),allMov{a});
        temp = [];
        for  i = 1:3
            filename = strcat(allMov{a},num2str(i),'.csv');
            varname = strcat('s',num2str(j),allMov{a},num2str(i));
            eval([varname,'=','csvread(filename)',';']);
            temp = [temp eval(varname)];
        end
        assignin('base',Varname,temp(1:20000,:));
        eval([Varname,'=','newnorm','([',Varname,'])',';']);
        varname_all = [strcat(allMov{a},num2str(j),'_test_raw_target') ', ' strcat(allMov{a},num2str(j),'_train_split'),... 
                      ', ' strcat(allMov{a},num2str(j),'_test_split') ', ' strcat(allMov{a},num2str(j),'_train_split_target'),...
                      ', ' strcat(allMov{a},num2str(j),'_test_split_target')];
        eval(['[',varname_all,']','=','EMGdataprocess3_new_FL','(',Varname,',','a',')',';']);
    end
%%%%%%%%%%%%%%%%%%%%%%%%% ??????????????? %%%%%%%%%%%%%%%%%%%%%%%    
    

% ????????Target test raw data? Input_train_split_data?Target_train_split_data?  
% Input_test_split_data? Target_test_split_data? ????5???   
    %% Target test raw data
    targetTestRawDataName = [];
    for a1 = 1:15
        targetTestRawDataName = [targetTestRawDataName, strcat(allMov{a1},num2str(j),'_test_raw_target'), ' '];
    end
    eval([strcat('Target_test_raw_data',num2str(j)), '=', '[', targetTestRawDataName, ']' ,';']);
    
%%%%%%%%%%%%%%%%%%%%%%%% ???????????????? %%%%%%%%%%%%%%%%%%%%%%    
    %% Input_train_split_data
    inputTrainSplitDataName = [];
    for a1 = 1:15
        inputTrainSplitDataName = [inputTrainSplitDataName, strcat(allMov{a1},num2str(j),'_train_split'), ' '];
    end
    eval([strcat('Input_train_split_data',num2str(j)), '=', '[', inputTrainSplitDataName, ']' ,';']);
%%%%%%%%%%%%%%%% ??????????? ??15???????? %%%%%%%%%%%%%%%%%%%    
    %% Target_train_split_data
    targetTrainSplitDataName = [];
    for a1 = 1:15
        targetTrainSplitDataName = [targetTrainSplitDataName, strcat(allMov{a1},num2str(j),'_train_split_target'), ' '];
    end
    eval([strcat('Target_train_split_data',num2str(j)), '=', '[', targetTrainSplitDataName, ']' ,';']);
    
    %% Input_test_split_data
    inputTestSplitDataName = [];
    for a1 = 1:15
        inputTestSplitDataName = [inputTestSplitDataName, strcat(allMov{a1},num2str(j),'_test_split'), ' '];
    end
    eval([strcat('Input_test_split_data',num2str(j)), '=', '[', inputTestSplitDataName, ']' ,';']);
    
    %% Target_test_split_data
    targetTestSplitDataName = [];
    for a1 = 1:15
        targetTestSplitDataName = [targetTestSplitDataName, strcat(allMov{a1},num2str(j),'_test_split_target'), ' '];
    end
    eval([strcat('Target_test_split_data',num2str(j)), '=', '[', targetTestSplitDataName, ']' ,';']);
    
    cd ..
end

%% The whole test dataset  ???????whole??
Input_test = [Input_test_split_data1 Input_test_split_data2 Input_test_split_data3 Input_test_split_data4 ...
    Input_test_split_data5 Input_test_split_data6 Input_test_split_data7 Input_test_split_data8];

Target_test = [Target_test_split_data1 Target_test_split_data2 Target_test_split_data3 Target_test_split_data4 ...
    Target_test_split_data5 Target_test_split_data6 Target_test_split_data7 Target_test_split_data8];

Target_test_raw = [Target_test_raw_data1 Target_test_raw_data2 Target_test_raw_data3 Target_test_raw_data4 ...
    Target_test_raw_data5 Target_test_raw_data6 Target_test_raw_data7 Target_test_raw_data8];
