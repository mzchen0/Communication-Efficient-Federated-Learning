usernumber_all = 8;
i=1;
Window = 500;
iter_indiv =10; % interations for training the local models
iter_ftl = 50; % interations for federated transfer learning
Incre = 50;

 Input_train_split_data = eval(['Input_train_split_data',num2str(i)]);
        Target_train_split_data = eval(['Target_train_split_data',num2str(i)]);
        Input_test_split_data = eval(['Input_test_split_data',num2str(i)]);
        Target_test_split_data = eval(['Target_test_split_data',num2str(i)]);
        
        % Generate the training and test data
        XTrain = zeros(Window,8,1,numel(Input_train_split_data));
        a = cell2mat(Input_train_split_data); 
        b = zeros(Window,8,1,numel(Input_train_split_data));
        for m = 1:numel(Input_train_split_data)
            b(:,:,1,m) = a(:,((m-1)*8+1):m*8);
        end
        XTrain = b;
        a = [];
        b = [];

        XTest = zeros(Window,8,1,numel(Input_test_split_data));
        a = cell2mat(Input_test_split_data); 
        b = zeros(Window,8,1,numel(Input_test_split_data));
        for m = 1:numel(Input_test_split_data)
            b(:,:,1,m) = a(:,((m-1)*8+1):m*8);
        end
        XTest = b;

        YTrain = zeros(size(Target_train_split_data,2),1);
        for m = 1:size(Target_train_split_data,2)
            YTrain(m) = find(Target_train_split_data(:,m) == 1);
        end
        YTrain = categorical(YTrain);

        YTest = zeros(size(Target_test_split_data,2),1);
        for m = 1:size(Target_test_split_data,2)
            YTest(m) = find(Target_test_split_data(:,m) == 1);
        end
        YTest = categorical(YTest);

        imageSize = size(XTrain);
        imageSize = imageSize(1:3);
        %% Configuration of CNN's layer
        
        layers = [
            imageInputLayer(imageSize)
            convolution2dLayer([2 4],50)
            batchNormalizationLayer
            reluLayer
            maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 2],100)
            batchNormalizationLayer
            reluLayer
            maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 2],100)
            batchNormalizationLayer
            reluLayer
            %maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 1],50)
            reluLayer
            maxPooling2dLayer([2 1],'Stride',[2,1])
            %fullyConnectedLayer(100)
            fullyConnectedLayer(15)
            %dropoutLayer(0.1)
            fullyConnectedLayer(15)
            %fullyConnectedLayer(10)
            softmaxLayer
            classificationLayer];
        
        options = trainingOptions('adam',...
            'MaxEpochs',iter_indiv,...
            'Verbose',false,...
            'Plots','training-progress');
            
             
            
        eval(['[','cnn',num2str(i),', ','traininginfo',']', '=','trainNetwork(XTrain,YTrain,layers,options)',';']);
        
        
        %% Observe the test accuracy of each local model when it is training individually
        
        predictedLabels_train = classify(eval(['cnn',num2str(i)]),XTrain);
        valLabels_train = YTrain;
        accuracy_train_cnn = sum(predictedLabels_train == valLabels_train)/numel(valLabels_train);
        
        [predictedLabels] = classify(eval(['cnn',num2str(i)]),XTest);                                              
        valLabels = YTest;
        accuracy_test_cnn = sum(predictedLabels == valLabels)/numel(valLabels);
        
        b1 = eval(['Target_test_raw_data',num2str(i),';']);

        d = zeros(size(b1,2),1);
         for m = 1:size(b1,2)
             d(m) = find(b1(:,m) == max(b1(:,m)));
         end

        y = grp2idx(classify(eval(['cnn',num2str(i)]),XTest));

        num_samples = (20000 - Window)/Incre + 1;
        temp = zeros(size(b1,2),1);
         for m = 1:size(b1,2)
             temp(m) = mode(y((m-1)*num_samples+1:m*num_samples));
         end

        accuracy_after_voting = size(find(temp == d),1)/size(d,1);
        
        fprintf('The test accuracy of local model %d: %f, before voting, it is %f\n',i,accuracy_after_voting,accuracy_test_cnn)
         %% Record the Dense weights of each CNN
        model = eval(['cnn',num2str(i)]);
        
        for j = 1:Layers_number
            W{j, i} = model.Layers(Layer_index(j)).Weights;
            B{j, i} = model.Layers(Layer_index(j)).Bias;
        end   
        
        
        
       %%% 2,6,10,13,16,17
