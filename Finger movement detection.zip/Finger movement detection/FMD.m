clear all
Window=500;
%eval(['dataProcess']);
iter_indiv =1;
Incre = 50;
Layer_index=[2,6,10,13,16,17];
Layers_number=length(Layer_index);
alpha=0.85;
      %  imageSize = size(XTrain);
        imageSize = [500 8 1];
        %% Configuration of CNN's layer        
        layer = [
            imageInputLayer(imageSize)
            convolution2dLayer([2 4],50,'Padding',2,'BiasLearnRateFactor',2)
            batchNormalizationLayer
            reluLayer
            maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 2],100)
            batchNormalizationLayer
            reluLayer
            maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 2],100,'Padding',2,'BiasLearnRateFactor',2)
            batchNormalizationLayer
            reluLayer
            %maxPooling2dLayer(2,'Stride',[2,1])
            convolution2dLayer([10 1],50,'Padding',2,'BiasLearnRateFactor',2)
            reluLayer
            maxPooling2dLayer([2 1],'Stride',[2,1])
            %fullyConnectedLayer(100)
            fullyConnectedLayer(15,'BiasLearnRateFactor',2)
            %dropoutLayer(0.1)
            fullyConnectedLayer(15,'BiasLearnRateFactor',2)
            %fullyConnectedLayer(10)
            softmaxLayer
            classificationLayer];
        
          options = trainingOptions('adam',...
          'ExecutionEnvironment','parallel',...
           'MiniBatchSize', 75, ...
            'MaxEpochs',iter_indiv,...
            'Verbose',true);

%     options = trainingOptions('adam',...
%            'MiniBatchSize', 75, ...
%             'MaxEpochs',iter_indiv,...
%             'Verbose',true);
  %   'Plots','training-progress',...
        
       
w1length= 2*4*1*50;

w2length= 10*2*50*100;

w3length=10*2*100*100;

w4length=10*100*50;

w5length=15*35750;

w6length=15*15;


b1length=50;

b2length=100;

b3length=100;

b4length=50;

b5length=15;        
        
b6length=15;         



%%%%%%%%%%%%%%%%%%%%%%%% coding setting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
varSize = 32; 
v_fQRate = [1, 2];
v_nQuantizaers   = [...          % Curves
    0 ...                   % Dithered 3-D lattice quantization 
    1 ...                   % Dithered 2-D lattice quantization    
    1 ...                   % Dithered scalar quantization      
    1 ...                   % QSGD 
    1 ...                   % Uniform quantization with random unitary rotation    
    1 ...                   % Subsampling with 3 bits quantizers
    ];

global gm_fGenMat2D;
global gm_fLattice2D;
% Clear lattices
gm_fGenMat2D = [];
gm_fLattice2D = [];
% Do full search over the lattice
stSettings.OptSearch = 1;

stSettings.type =2;
stSettings.scale=1;
s_fRate=4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



        
iteration=300;  %%%% 
accuracy_test_cnn=zeros(iteration,1);
usernumber=15;
numberofuser=10;
d=[407.3618
  452.8960
   63.4934
  456.6879
  316.1796
   48.7702
  139.2491
  273.4408
  478.7534
  482.4443
   78.8065
  485.2964
  478.5835
  242.6878
  400.1402];

%rand(usernumber,1)*500; 
% d=[116.9816
%   363.8833
%   139.5300
%    361.0612
%    445.4524
%    363.4695
%    83.2137
%   104.7784];

proposed=1;
baseline1=0;
baseline2=0;
baseline3=0;


    w1=zeros(2,4,1,50,usernumber);
w2=zeros(10,2,50,100,usernumber);
w3=zeros(10,2,100,100,usernumber);
w4=zeros(10,1,100,50,usernumber);
w5=zeros(15,35750,usernumber);
w6=zeros(15,15,usernumber);

b1=zeros(1,1,50,usernumber);
b2=zeros(1,1,100,usernumber);
b3=zeros(1,1,100,usernumber);
b4=zeros(1,1,50,usernumber);
b5=zeros(15,1,usernumber);
b6=zeros(15,1,usernumber);





load('testdata2');

XTrain1=cell(usernumber,1);
YTrain1=cell(usernumber,1);
for ii=1:1:usernumber
eval(['load data',num2str(ii)]);
XTrain1{ii,1}=XTrain;
YTrain1{ii,1}=YTrain;
end

for i=1:1:iteration

if i==1
    globalw1=zeros(2,4,1,50);
globalw2=zeros(10,2,50,100);
globalw3=zeros(10,2,100,100);
globalw4=zeros(10,1,100,50);
globalw5=zeros(15,2550);
globalw6=zeros(15,15);

    globalb1=zeros(1,1,50);
globalb2=zeros(1,1,100);
globalb3=zeros(1,1,100);
globalb4=zeros(1,1,50);
globalb5=zeros(15,1);
globalb6=zeros(15,1);

end




if i>1


    layer(2).Weights=globalw1;

    layer(6).Weights=globalw2;

     layer(10).Weights=globalw3;
     layer(13).Weights=globalw4;
    layer(16).Weights=globalw5;
    layer(17).Weights=globalw6;
     
         layer(2).Bias=globalb1;

    layer(6).Bias=globalb2;

     layer(10).Bias=globalb3;
     layer(13).Bias=globalb4;
    layer(16).Bias=globalb5;
    layer(17).Bias=globalb6;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end  

for user = 1:usernumber


      
 % eval(['[','cnn',num2str(user),', ','traininginfo',']', '=','trainNetwork(XTrain,YTrain,layer,options)',';']);
 
   
      
        
%     if i==30           
%         options = trainingOptions('adam',...
%              'InitialLearnRate', 0.008,...
%             'ExecutionEnvironment','parallel',...
%             'MaxEpochs',iter_indiv,...
%             'Verbose',false);
%     elseif i==45
%         options = trainingOptions('adam',...
%              'InitialLearnRate', 0.0006,...
%             'ExecutionEnvironment','parallel',...
%             'MaxEpochs',iter_indiv,...
%             'Verbose',false);
%       elseif i>40
%         options = trainingOptions('adam',...
%              'InitialLearnRate', 0.0004,...
%             'ExecutionEnvironment','parallel',...
%             'MaxEpochs',iter_indiv,...
%             'Verbose',false);
%     end









       % eval(['[','cnn',num2str(user),', ','traininginfo',']', '=','trainNetwork(XTrain,YTrain,layer,options)',';']);
        
        netvaluable = trainNetwork(XTrain1{user,1},YTrain1{user,1},layer,options);


       [predictedLabels] = classify(netvaluable,XTest);                                              
        valLabels = YTest;
        accuracy_test_cnn(i,user) = sum(predictedLabels == valLabels)/numel(valLabels);

        
        
        %% Observe the test accuracy of each local model when it is training individually
        
      %  predictedLabels_train = classify(eval(['cnn',num2str(user)]),XTrain);
      %  valLabels_train = YTrain;
      %  accuracy_train_cnn = sum(predictedLabels_train == valLabels_train)/numel(valLabels_train);
        
            
        %%%%%%%%%%%%%%% after voting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
%         b1 = eval(['Target_test_raw_data',num2str(i),';']);
% 
%         d = zeros(size(b1,2),1);
%          for m = 1:size(b1,2)
%              d(m) = find(b1(:,m) == max(b1(:,m)));
%          end
% 
%         y = grp2idx(classify(eval(['cnn',num2str(i)]),XTest));
% 
%         num_samples = (20000 - Window)/Incre + 1;
%         temp = zeros(size(b1,2),1);
%          for m = 1:size(b1,2)
%              temp(m) = mode(y((m-1)*num_samples+1:m*num_samples));
%          end
% 
%         accuracy_after_voting = size(find(temp == d),1)/size(d,1);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
     %   fprintf('The test accuracy of local model %d: %f, before voting, it is %f\n',i,accuracy_after_voting,accuracy_test_cnn)
       
     
     
%%%%%%%%%%%%% global model for each user, which consists of 4 matrices  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Record trained local FL model.

w1(:,:,:,:,user)=netvaluable.Layers(2).Weights;

w2(:,:,:,:,user)=netvaluable.Layers(6).Weights;

     w3(:,:,:,:,user)=netvaluable.Layers(10).Weights;
    w4(:,:,:,:,user)=netvaluable.Layers(13).Weights;
w5(:,:,user)=netvaluable.Layers(16).Weights;

w6(:,:,user)=netvaluable.Layers(17).Weights;
     
     
b1(:,:,:,user)=netvaluable.Layers(2).Bias;

b2(:,:,:,user)=netvaluable.Layers(6).Bias;

   b3(:,:,:,user)=netvaluable.Layers(10).Bias;
   b4(:,:,:,user)=netvaluable.Layers(13).Bias;
   b5(:,user)=netvaluable.Layers(16).Bias;
   b6(:,user)=netvaluable.Layers(17).Bias;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%% Calculate the gradient of local FL model of each user%%%%%%%    

if i==1    
     
deviationw1all(:,:,:,:,user)=w1(:,:,:,:,user);
deviationw2all(:,:,:,:,user)=w2(:,:,:,:,user);
deviationw3all(:,:,:,:,user)=w3(:,:,:,:,user);
deviationw4all(:,:,:,:,user)=w4(:,:,:,:,user);
deviationw5all(:,:,user)=w5(:,:,user);
deviationw6all(:,:,user)=w6(:,:,user);


deviationb1all(:,:,:,user)=b1(:,:,:,user);
deviationb2all(:,:,:,user)=b2(:,:,:,user);
deviationb3all(:,:,:,user)=b3(:,:,:,user);
deviationb4all(:,:,:,user)=b4(:,:,:,user);
deviationb5all(:,user)= b5(:,user);
deviationb6all(:,user)= b6(:,user);

else
    
    
deviationw1all(:,:,:,:,user)=w1(:,:,:,:,user)-globalw1;
deviationw2all(:,:,:,:,user)=w2(:,:,:,:,user)-globalw2;
deviationw3all(:,:,:,:,user)=w3(:,:,:,:,user)-globalw3;
deviationw4all(:,:,:,:,user)=w4(:,:,:,:,user)-globalw4;
deviationw5all(:,:,user)=w5(:,:,user)-globalw5;
deviationw6all(:,:,user)=w6(:,:,user)-globalw6;

deviationb1all(:,:,:,user)=b1(:,:,:,user)-globalb1;
deviationb2all(:,:,:,user)=b2(:,:,:,user)-globalb2;
deviationb3all(:,:,:,user)=b3(:,:,:,user)-globalb3;
deviationb4all(:,:,:,user)=b4(:,:,:,user)-globalb4;
deviationb5all(:,user)= b5(:,user)-globalb5; 
deviationb6all(:,user)= b6(:,user)-globalb6; 
        
end




end




if proposed==1
 gradient=zeros(usernumber,1);   
for jjj=1:1:usernumber
gradient(jjj,1)=sum(sqrt(deviationw1all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw2all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw3all(:,:,:,:,jjj).^2),'all')...
                +sum(sqrt(deviationw4all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw5all(:,:,jjj).^2),'all')+sum(sqrt(deviationw6all(:,:,jjj).^2),'all')...
                +sum(sqrt(deviationb1all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb2all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb3all(:,:,:,jjj).^2),'all')...
                +sum(sqrt(deviationb4all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb5all(:,jjj).^2),'all')+sum(sqrt(deviationb6all(:,jjj).^2),'all');
end

 [xx,dex]=sort(gradient);
 
 probability=gradient/sum(gradient);
     probabilityd=(max(d)-d)/sum(max(d)-d);
     
   probability=probability*alpha+(1-alpha)*probabilityd;
   
      vector=[1:1:usernumber];
     for llll=1:1:numberofuser

    bb(i,llll)=randsrc(1,1,[vector; probability']);
    
    position=find(vector==bb(i,llll));
    probability1=probability(position,1);
    probability(position)=[];
    vector(position)=[];
    probability=probability./(1-probability1);
    %end
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%% reshape the gradient of local FL model of each user%%%%%%%        

parfor code=1:1:numberofuser


 deviationw1=deviationw1all(:,:,:,:,bb(i,code));
deviationw2=deviationw2all(:,:,:,:,bb(i,code));
deviationw3=deviationw3all(:,:,:,:,bb(i,code));
deviationw4=deviationw4all(:,:,:,:,bb(i,code));
deviationw5=deviationw5all(:,:,bb(i,code));
deviationw6=deviationw6all(:,:,bb(i,code));

deviationb1=deviationb1all(:,:,:,bb(i,code));
deviationb2=deviationb2all(:,:,:,bb(i,code));
deviationb3=deviationb3all(:,:,:,bb(i,code));
deviationb4=deviationb4all(:,:,:,bb(i,code));
deviationb5=deviationb5all(:,bb(i,code));
deviationb6=deviationb6all(:,bb(i,code));  
    
    
    
w1vector=reshape(deviationw1,[w1length,1]);

w2vector=reshape(deviationw2,[w2length,1]);

w3vector=reshape(deviationw3,[w3length,1]);

w4vector=reshape(deviationw4,[w4length,1]);


w5vector=reshape(deviationw5,[w5length,1]);   

w6vector=reshape(deviationw6,[w6length,1]);  




b1vector=[];
b2vector=[];
b3vector=[];
b4vector=[];

b1vector(:,1)=deviationb1(1,1,:);
b2vector(:,1)=deviationb2(1,1,:);
b3vector(:,1)=deviationb3(1,1,:);
b4vector(:,1)=deviationb4(1,1,:);




    m_fH1 = [w1vector;w2vector;w3vector;w4vector;w5vector;w6vector;...
             b1vector;b2vector;b3vector;b4vector;deviationb5;deviationb6]; 
%    
   [m_fHhat1, ~] = m_fQuantizeData(m_fH1, s_fRate, stSettings); % coding and decoding
 
   bstart=w1length+w2length+w3length+w4length+w5length+w6length;
   
 %%%%%%%%%%%%%%%% reshape the gradient of the loss function after coding %%%%%%%%%%%%  
 deviationw1=reshape(m_fHhat1(1:w1length),[2,4,1,50]);
  deviationw2=reshape(m_fHhat1(w1length+1:w1length+w2length),[10,2,50,100]);
  deviationw3=reshape(m_fHhat1(w1length+w2length+1:w1length+w2length+w3length),[10,2,100,100]);
deviationw4=reshape(m_fHhat1(w1length+w2length+w3length+1:w1length+w2length+w3length+w4length),[10,1,100,50]);
deviationw5=reshape(m_fHhat1(w1length+w2length+w3length+w4length+1:w1length+w2length+w3length+w4length+w5length),[15,35750]);
deviationw6=reshape(m_fHhat1(w1length+w2length+w3length+w4length+w5length+1:bstart),[15,15]);


 deviationb1(1,1,:)=reshape(m_fHhat1(bstart+1:bstart+b1length),[1,1,50]);
  deviationb2(1,1,:)=reshape(m_fHhat1(bstart+b1length+1:bstart+b1length+b2length),[1,1,100]);
  deviationb3(1,1,:)=reshape(m_fHhat1(bstart+b1length+b2length+1:bstart+b1length+b2length+b3length),[1,1,100]);
deviationb4(1,1,:)=reshape(m_fHhat1(bstart+b1length+b2length+b3length+1:bstart+b1length+b2length+b3length+b4length),[1,1,50]);
%m_fHhat1(bstart+b1length+b2length+b3length+1:bstart+b1length+b2length+b3length+b4length);
deviationb5(:,1)=m_fHhat1(bstart+b1length+b2length+b3length+b4length+1:bstart+b1length+b2length+b3length+b4length+b5length);
deviationb6(:,1)=m_fHhat1(bstart+b1length+b2length+b3length+b4length+b5length+1:bstart+b1length+b2length+b3length+b4length+b5length+b6length);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


faroutw1(:,:,:,:,code)=deviationw1;

faroutw2(:,:,:,:,code)=deviationw2;

faroutw3(:,:,:,:,code)=deviationw3;

faroutw4(:,:,:,:,code)=deviationw4;

faroutw5(:,:,code)=deviationw5;

faroutw6(:,:,code)=deviationw6;

faroutb1(:,:,:,code)=deviationb1;
faroutb2(:,:,:,code)=deviationb2;
faroutb3(:,:,:,code)=deviationb3;
faroutb4(:,:,:,code)=deviationb4;
faroutb5(:,code)=deviationb5;
faroutb6(:,code)=deviationb6;

end

 %%%%%%%%%%%%%%%% calculate the local FL model of each user after coding %%%%%%%%%%%%  

for code=1:1:numberofuser
    if i==1
   
   w1(:,:,:,:,bb(i,code))=faroutw1(:,:,:,:,code);
w2(:,:,:,:,bb(i,code))=faroutw2(:,:,:,:,code);
 w3(:,:,:,:,bb(i,code))=faroutw3(:,:,:,:,code);
w4(:,:,:,:,bb(i,code))=faroutw4(:,:,:,:,code);
w5(:,:,bb(i,code))=faroutw5(:,:,code);
w6(:,:,bb(i,code))=faroutw6(:,:,code);

b1(:,:,:,bb(i,code))=faroutb1(:,:,:,code);
b2(:,:,:,bb(i,code))=faroutb2(:,:,:,code);
b3(:,:,:,bb(i,code))=faroutb3(:,:,:,code);
b4(:,:,:,bb(i,code))=faroutb4(:,:,:,code);
b5(:,bb(i,code))=faroutb5(:,code);
b6(:,bb(i,code))=faroutb6(:,code);
              
    else       
  w1(:,:,:,:,bb(i,code))=faroutw1(:,:,:,:,code)+globalw1;
w2(:,:,:,:,bb(i,code))=faroutw2(:,:,:,:,code)+globalw2;
 w3(:,:,:,:,bb(i,code))=faroutw3(:,:,:,:,code)+globalw3;
w4(:,:,:,:,bb(i,code))=faroutw4(:,:,:,:,code)+globalw4;
w5(:,:,bb(i,code))=faroutw5(:,:,code)+globalw5;
w6(:,:,bb(i,code))=faroutw6(:,:,code)+globalw6;

b1(:,:,:,bb(i,code))=faroutb1(:,:,:,code)+globalb1;
b2(:,:,:,bb(i,code))=faroutb2(:,:,:,code)+globalb2;
b3(:,:,:,bb(i,code))=faroutb3(:,:,:,code)+globalb3;
b4(:,:,:,bb(i,code))=faroutb4(:,:,:,code)+globalb4;
b5(:,bb(i,code))=faroutb5(:,code)+globalb5;     
b6(:,bb(i,code))=faroutb6(:,code)+globalb6;     
        
    end
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    



 %%%%%%%%%%%%%%%% update the global FL model  %%%%%%%%%%%%  
globalw1=1/numberofuser*sum(w1(:,:,:,:,bb(i,:)),5);  % global training model
globalw2=1/numberofuser*sum(w2(:,:,:,:,bb(i,:)),5);  % global training model
globalw3=1/numberofuser*sum(w3(:,:,:,:,bb(i,:)),5);
globalw4=1/numberofuser*sum(w4(:,:,:,:,bb(i,:)),5);
globalw5=1/numberofuser*sum(w5(:,:,bb(i,:)),3);
globalw6=1/numberofuser*sum(w6(:,:,bb(i,:)),3);


globalb1=1/numberofuser*sum(b1(:,:,:,bb(i,:)),4);  % global training model
globalb2=1/numberofuser*sum(b2(:,:,:,bb(i,:)),4);  % global training model
globalb3=1/numberofuser*sum(b3(:,:,:,bb(i,:)),4);
globalb4=1/numberofuser*sum(b4(:,:,:,bb(i,:)),4);
globalb5=1/numberofuser*sum(b5(:,bb(i,:)),2);

globalb6=1/numberofuser*sum(b6(:,bb(i,:)),2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%% Delay calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  userconnectvector=zeros(1,usernumber);
%  userconnectvector(1,bb(i,:))=1;
% 
%   iterationtime(i)=mindelay(userconnectvector,RBnumber,time);
%   iterationtimerandom(i)=randomdelay(userconnectvector,RBnumber,time);

end







if baseline1==1
probability=ones(usernumber,1)/usernumber;
   
   
      vector=[1:1:usernumber];
     for llll=1:1:numberofuser

    bb(i,llll)=randsrc(1,1,[vector; probability']);
    
    position=find(vector==bb(i,llll));
    probability1=probability(position,1);
    probability(position)=[];
    vector(position)=[];
    probability=probability./(1-probability1);
    %end
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%% reshape the gradient of local FL model of each user%%%%%%%        

for code=1:1:numberofuser


 deviationw1=deviationw1all(:,:,:,:,bb(i,code));
deviationw2=deviationw2all(:,:,:,:,bb(i,code));
deviationw3=deviationw3all(:,:,:,:,bb(i,code));
deviationw4=deviationw4all(:,:,:,:,bb(i,code));
deviationw5=deviationw5all(:,:,bb(i,code));
deviationw6=deviationw6all(:,:,bb(i,code));

deviationb1=deviationb1all(:,:,:,bb(i,code));
deviationb2=deviationb2all(:,:,:,bb(i,code));
deviationb3=deviationb3all(:,:,:,bb(i,code));
deviationb4=deviationb4all(:,:,:,bb(i,code));
deviationb5=deviationb5all(:,bb(i,code));
deviationb6=deviationb6all(:,bb(i,code));  
    
    
    
w1vector=reshape(deviationw1,[w1length,1]);

w2vector=reshape(deviationw2,[w2length,1]);

w3vector=reshape(deviationw3,[w3length,1]);

w4vector=reshape(deviationw4,[w4length,1]);


w5vector=reshape(deviationw5,[w5length,1]);   

w6vector=reshape(deviationw6,[w6length,1]);  




b1vector=[];
b2vector=[];
b3vector=[];
b4vector=[];

b1vector(:,1)=deviationb1(1,1,:);
b2vector(:,1)=deviationb2(1,1,:);
b3vector(:,1)=deviationb3(1,1,:);
b4vector(:,1)=deviationb4(1,1,:);




    m_fH1 = [w1vector;w2vector;w3vector;w4vector;w5vector;w6vector;...
             b1vector;b2vector;b3vector;b4vector;deviationb5;deviationb6]; 
%    
   [m_fHhat1, ~] = m_fQuantizeData(m_fH1, s_fRate, stSettings); % coding and decoding
 
   bstart=w1length+w2length+w3length+w4length+w5length+w6length;
   
 %%%%%%%%%%%%%%%% reshape the gradient of the loss function after coding %%%%%%%%%%%%  
 deviationw1=reshape(m_fHhat1(1:w1length),[2,4,1,50]);
  deviationw2=reshape(m_fHhat1(w1length+1:w1length+w2length),[10,2,50,100]);
  deviationw3=reshape(m_fHhat1(w1length+w2length+1:w1length+w2length+w3length),[10,2,100,100]);
deviationw4=reshape(m_fHhat1(w1length+w2length+w3length+1:w1length+w2length+w3length+w4length),[10,1,100,50]);
deviationw5=reshape(m_fHhat1(w1length+w2length+w3length+w4length+1:w1length+w2length+w3length+w4length+w5length),[15,2550]);
deviationw6=reshape(m_fHhat1(w1length+w2length+w3length+w4length+w5length+1:bstart),[15,15]);


 deviationb1(1,1,:)=reshape(m_fHhat1(bstart+1:bstart+b1length),[1,1,50]);
  deviationb2(1,1,:)=reshape(m_fHhat1(bstart+b1length+1:bstart+b1length+b2length),[1,1,100]);
  deviationb3(1,1,:)=reshape(m_fHhat1(bstart+b1length+b2length+1:bstart+b1length+b2length+b3length),[1,1,100]);
deviationb4(1,1,:)=reshape(m_fHhat1(bstart+b1length+b2length+b3length+1:bstart+b1length+b2length+b3length+b4length),[1,1,50]);
%m_fHhat1(bstart+b1length+b2length+b3length+1:bstart+b1length+b2length+b3length+b4length);
deviationb5(:,1)=m_fHhat1(bstart+b1length+b2length+b3length+b4length+1:bstart+b1length+b2length+b3length+b4length+b5length);
deviationb6(:,1)=m_fHhat1(bstart+b1length+b2length+b3length+b4length+b5length+1:bstart+b1length+b2length+b3length+b4length+b5length+b6length);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%% calculate the local FL model of each user after coding %%%%%%%%%%%%  

    if i==1
   
   w1(:,:,:,:,bb(i,code))=deviationw1;
w2(:,:,:,:,bb(i,code))=deviationw2;
 w3(:,:,:,:,bb(i,code))=deviationw3;
w4(:,:,:,:,bb(i,code))=deviationw4;
w5(:,:,bb(i,code))=deviationw5;
w6(:,:,bb(i,code))=deviationw6;

b1(:,:,:,bb(i,code))=deviationb1;
b2(:,:,:,bb(i,code))=deviationb2;
b3(:,:,:,bb(i,code))=deviationb3;
b4(:,:,:,bb(i,code))=deviationb4;
b5(:,bb(i,code))=deviationb5;
b6(:,bb(i,code))=deviationb6;
              
    else       
  w1(:,:,:,:,bb(i,code))=deviationw1+globalw1;
w2(:,:,:,:,bb(i,code))=deviationw2+globalw2;
 w3(:,:,:,:,bb(i,code))=deviationw3+globalw3;
w4(:,:,:,:,bb(i,code))=deviationw4+globalw4;
w5(:,:,bb(i,code))=deviationw5+globalw5;
w6(:,:,bb(i,code))=deviationw6+globalw6;

b1(:,:,:,bb(i,code))=deviationb1+globalb1;
b2(:,:,:,bb(i,code))=deviationb2+globalb2;
b3(:,:,:,bb(i,code))=deviationb3+globalb3;
b4(:,:,:,bb(i,code))=deviationb4+globalb4;
b5(:,bb(i,code))=deviationb5+globalb5;     
b6(:,bb(i,code))=deviationb6+globalb6;     
        
    end
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    



 %%%%%%%%%%%%%%%% update the global FL model  %%%%%%%%%%%%  
globalw1=1/numberofuser*sum(w1(:,:,:,:,bb(i,:)),5);  % global training model
globalw2=1/numberofuser*sum(w2(:,:,:,:,bb(i,:)),5);  % global training model
globalw3=1/numberofuser*sum(w3(:,:,:,:,bb(i,:)),5);
globalw4=1/numberofuser*sum(w4(:,:,:,:,bb(i,:)),5);
globalw5=1/numberofuser*sum(w5(:,:,bb(i,:)),3);
globalw6=1/numberofuser*sum(w6(:,:,bb(i,:)),3);


globalb1=1/numberofuser*sum(b1(:,:,:,bb(i,:)),4);  % global training model
globalb2=1/numberofuser*sum(b2(:,:,:,bb(i,:)),4);  % global training model
globalb3=1/numberofuser*sum(b3(:,:,:,bb(i,:)),4);
globalb4=1/numberofuser*sum(b4(:,:,:,bb(i,:)),4);
globalb5=1/numberofuser*sum(b5(:,bb(i,:)),2);

globalb6=1/numberofuser*sum(b6(:,bb(i,:)),2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%% Delay calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  userconnectvector=zeros(1,usernumber);
%  userconnectvector(1,bb(i,:))=1;
% 
%  iterationtime(i)=mindelay(userconnectvector,RBnumber,time);
%  iterationtimerandom(i)=randomdelay(userconnectvector,RBnumber,time);

end

%%%%%%%%%%%%%%%%%%%%%%%% Baseline2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if baseline2==1
     gradient=zeros(usernumber,1);   
for jjj=1:1:usernumber
gradient(jjj,1)=sum(sqrt(deviationw1all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw2all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw3all(:,:,:,:,jjj).^2),'all')...
                +sum(sqrt(deviationw4all(:,:,:,:,jjj).^2),'all')+sum(sqrt(deviationw5all(:,:,jjj).^2),'all')+sum(sqrt(deviationw6all(:,:,jjj).^2),'all')...
                +sum(sqrt(deviationb1all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb2all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb3all(:,:,:,jjj).^2),'all')...
                +sum(sqrt(deviationb4all(:,:,:,jjj).^2),'all')+sum(sqrt(deviationb5all(:,jjj).^2),'all')+sum(sqrt(deviationb6all(:,jjj).^2),'all');
end

 [xx,dex]=sort(gradient);
 
 probability=gradient/sum(gradient);
     probabilityd=(max(d)-d)/sum(max(d)-d);
     
   probability=probability*alpha+(1-alpha)*probabilityd;
   
      vector=[1:1:usernumber];
     for llll=1:1:numberofuser

    bb(i,llll)=randsrc(1,1,[vector; probability']);
    
    position=find(vector==bb(i,llll));
    probability1=probability(position,1);
    probability(position)=[];
    vector(position)=[];
    probability=probability./(1-probability1);
    %end
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %%%%%%%%%%%%%%%% update the global FL model  %%%%%%%%%%%%  
globalw1=1/numberofuser*sum(w1(:,:,:,:,bb(i,:)),5);  % global training model
globalw2=1/numberofuser*sum(w2(:,:,:,:,bb(i,:)),5);  % global training model
globalw3=1/numberofuser*sum(w3(:,:,:,:,bb(i,:)),5);
globalw4=1/numberofuser*sum(w4(:,:,:,:,bb(i,:)),5);
globalw5=1/numberofuser*sum(w5(:,:,bb(i,:)),3);
globalw6=1/numberofuser*sum(w6(:,:,bb(i,:)),3);


globalb1=1/numberofuser*sum(b1(:,:,:,bb(i,:)),4);  % global training model
globalb2=1/numberofuser*sum(b2(:,:,:,bb(i,:)),4);  % global training model
globalb3=1/numberofuser*sum(b3(:,:,:,bb(i,:)),4);
globalb4=1/numberofuser*sum(b4(:,:,:,bb(i,:)),4);
globalb5=1/numberofuser*sum(b5(:,bb(i,:)),2);

globalb6=1/numberofuser*sum(b6(:,bb(i,:)),2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%% Delay calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  userconnectvector=zeros(1,usernumber);
%  userconnectvector(1,bb(i,:))=1;
%   
%  iterationtime(i)=mindelay(userconnectvector,RBnumber,time);
%  iterationtimerandom(i)=randomdelay(userconnectvector,RBnumber,time);

end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if baseline3==1
    
probability=ones(usernumber,1)/usernumber;
   
   
      vector=[1:1:usernumber];
     for llll=1:1:numberofuser

    bb(i,llll)=randsrc(1,1,[vector; probability']);
    
    position=find(vector==bb(i,llll));
    probability1=probability(position,1);
    probability(position)=[];
    vector(position)=[];
    probability=probability./(1-probability1);
    %end
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %%%%%%%%%%%%%%%% update the global FL model  %%%%%%%%%%%%  
globalw1=1/numberofuser*sum(w1(:,:,:,:,bb(i,:)),5);  % global training model
globalw2=1/numberofuser*sum(w2(:,:,:,:,bb(i,:)),5);  % global training model
globalw3=1/numberofuser*sum(w3(:,:,:,:,bb(i,:)),5);
globalw4=1/numberofuser*sum(w4(:,:,:,:,bb(i,:)),5);
globalw5=1/numberofuser*sum(w5(:,:,bb(i,:)),3);
globalw6=1/numberofuser*sum(w6(:,:,bb(i,:)),3);


globalb1=1/numberofuser*sum(b1(:,:,:,bb(i,:)),4);  % global training model
globalb2=1/numberofuser*sum(b2(:,:,:,bb(i,:)),4);  % global training model
globalb3=1/numberofuser*sum(b3(:,:,:,bb(i,:)),4);
globalb4=1/numberofuser*sum(b4(:,:,:,bb(i,:)),4);
globalb5=1/numberofuser*sum(b5(:,bb(i,:)),2);

globalb6=1/numberofuser*sum(b6(:,bb(i,:)),2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%% Delay calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  userconnectvector=zeros(1,usernumber);
%  userconnectvector(1,bb(i,:))=1;
%   
%  iterationtime(i)=mindelay(userconnectvector,RBnumber,time);
%  iterationtimerandom(i)=randomdelay(userconnectvector,RBnumber,time);

end

% tmp_net = cnn1.saveobj;
% 
% tmp_net.Layers(2).Weights=globalw1;
% 
% tmp_net.Layers(2).Bias=globalb1;
% 
% 
% tmp_net.Layers(6).Weights=globalw2;
% 
% tmp_net.Layers(6).Bias=globalb2;
% 
% 
% tmp_net.Layers(10).Weights=globalw3;
% 
% tmp_net.Layers(10).Bias=globalb3;
% 
% 
% tmp_net.Layers(13).Weights=globalw4;
% tmp_net.Layers(13).Bias=globalb4;
% 
% tmp_net.Layers(16).Weights=globalw5;
% 
% tmp_net.Layers(16).Bias=globalb5;
% tmp_net.Layers(17).Weights=globalw6;
% 
% tmp_net.Layers(17).Bias=globalb6;
% 
% 
% 
% cnn1 = cnn1.loadobj(tmp_net);
% 
% [predictedLabels] = classify(eval(['cnn',num2str(1)]),XTest);                                              
%     valLabels = YTest;
%  accuracy_test_cnn(i,1) = sum(predictedLabels == valLabels)/numel(valLabels);




display(i);
finalaccuracy_test_cnn(i,1)=sum(accuracy_test_cnn(i,:))/usernumber;
display(finalaccuracy_test_cnn(i,1));
save resultbioproposed accuracy_test_cnn d finalaccuracy_test_cnn i
end


%save data 
